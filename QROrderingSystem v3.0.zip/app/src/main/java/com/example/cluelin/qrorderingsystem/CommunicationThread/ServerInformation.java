package com.example.cluelin.qrorderingsystem.CommunicationThread;

/**
 * Created by cluelin on 2016-05-26.
 */
public interface ServerInformation{

    int port = 5001;

    String ORDER = "1";
    String CHECK_OUT = "2";
    String MODIFY = "3";
}
