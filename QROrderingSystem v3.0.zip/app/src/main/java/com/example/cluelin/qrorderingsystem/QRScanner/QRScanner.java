package com.example.cluelin.qrorderingsystem.QRScanner;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by cluelin on 2016-05-29.
 */
public class QRScanner extends CaptureActivity {
}
